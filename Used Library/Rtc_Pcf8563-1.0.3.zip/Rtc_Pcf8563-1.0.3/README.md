# Rtc_Pcf8563 Library

A Phillips PCF8563 Real Time Chip Arduino Library

Use the Arduino Library Manager to install me.
